package spmb.polstatstis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpmbPoliteknikStatistikaStisApplicationTests {

	@Test
	void contextLoads() {
	}

}
