package spmb.polstatstis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpmbPoliteknikStatistikaStisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpmbPoliteknikStatistikaStisApplication.class, args);
	}

}